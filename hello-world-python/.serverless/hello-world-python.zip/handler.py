import json


def hello(event, context):
    print('Hi in a different way another time!')
    return('Hello World!')
